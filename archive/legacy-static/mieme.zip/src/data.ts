import { MenuItem, Order } from './types.ts';

export const mockMenu: MenuItem[] = [
  {
    id: 'm1',
    name: 'MieME Spesial Original',
    description: 'Mie kenyal dengan topping ayam cincang, jamur, dan sayuran segar ditambah kaldu gurih.',
    price: 35000,
    image: 'https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?auto=format&fit=crop&q=80&w=800',
    category: 'makanan',
    estimatedTime: '10-15 menit',
    portion: '1 Orang',
  },
  {
    id: 'm2',
    name: 'MieME Pedas Mampus',
    description: 'Mie dengan tingkat kepedasan ekstra, dilengkapi pangsit goreng dan telur rebus.',
    price: 38000,
    image: 'https://images.unsplash.com/photo-1612927601601-6638404737ce?auto=format&fit=crop&q=80&w=800',
    category: 'makanan',
    estimatedTime: '15 menit',
    portion: '1 Orang',
  },
  {
    id: 'm3',
    name: 'MieME Truffle Premium',
    description: 'Kreasi mie premium dengan aroma truffle oil, irisan daging sapi wagyu, dan onsen egg.',
    price: 85000,
    image: 'https://images.unsplash.com/photo-1552611052-33e04de081de?auto=format&fit=crop&q=80&w=800',
    category: 'makanan',
    estimatedTime: '20 menit',
    portion: '1 Orang',
  },
  {
    id: 'd1',
    name: 'Es Teh Leci',
    description: 'Es teh manis segar berpadu dengan sirup leci dan buah leci asli.',
    price: 15000,
    image: 'https://images.unsplash.com/photo-1497935586351-b67a49e012bf?auto=format&fit=crop&q=80&w=800',
    category: 'minuman',
    estimatedTime: '5 menit',
    portion: '1 Gelas',
  },
  {
    id: 'd2',
    name: 'Kopi Susu Gula Aren',
    description: 'Kopi espresso robusta dengan susu segar dan manisnya gula aren alami.',
    price: 18000,
    image: 'https://images.unsplash.com/photo-1525088553748-01d0e2c88f5d?auto=format&fit=crop&q=80&w=800',
    category: 'minuman',
    estimatedTime: '5 menit',
    portion: '1 Gelas',
  }
];

export const mockOrders: Order[] = [
  {
    id: 'ORD-20231001-001',
    date: '2023-10-01T10:30:00Z',
    items: [
      { menuItem: mockMenu[0], quantity: 2 },
      { menuItem: mockMenu[3], quantity: 2 }
    ],
    total: 100000,
    status: 'Selesai',
  },
  {
    id: 'ORD-20231015-002',
    date: '2023-10-15T12:00:00Z',
    items: [
      { menuItem: mockMenu[2], quantity: 1 }
    ],
    total: 85000,
    status: 'Dikirim',
  }
];
