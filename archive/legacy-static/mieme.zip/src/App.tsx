import { Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout.tsx';

// Pages placeholders
import Home from './pages/Home.tsx';
import About from './pages/About.tsx';
import Menu from './pages/Menu.tsx';
import Award from './pages/Award.tsx';
import Testimonials from './pages/Testimonials.tsx';
import FAQ from './pages/FAQ.tsx';
import Register from './pages/Register.tsx';
import Login from './pages/Login.tsx';
import Profile from './pages/Profile.tsx';
import MenuDetail from './pages/MenuDetail.tsx';
import Cart from './pages/Cart.tsx';
import Checkout from './pages/Checkout.tsx';
import Payment from './pages/Payment.tsx';
import PaymentUpload from './pages/PaymentUpload.tsx';
import Orders from './pages/Orders.tsx';
import OrderDetail from './pages/OrderDetail.tsx';
import Review from './pages/Review.tsx';
import Favorites from './pages/Favorites.tsx';

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="about" element={<About />} />
        <Route path="menu" element={<Menu />} />
        <Route path="menu/:id" element={<MenuDetail />} />
        <Route path="award" element={<Award />} />
        <Route path="testimonials" element={<Testimonials />} />
        <Route path="faq" element={<FAQ />} />
        
        <Route path="register" element={<Register />} />
        <Route path="login" element={<Login />} />
        
        <Route path="profile" element={<Profile />} />
        <Route path="favorites" element={<Favorites />} />
        <Route path="cart" element={<Cart />} />
        <Route path="checkout" element={<Checkout />} />
        <Route path="payment" element={<Payment />} />
        <Route path="payment/upload" element={<PaymentUpload />} />
        
        <Route path="orders" element={<Orders />} />
        <Route path="orders/:id" element={<OrderDetail />} />
        <Route path="orders/:id/review" element={<Review />} />
      </Route>
    </Routes>
  );
}
