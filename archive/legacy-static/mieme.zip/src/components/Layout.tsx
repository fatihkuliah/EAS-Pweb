import React from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import { ShoppingCart, Heart, User, Menu, X, LogOut, ChevronDown } from 'lucide-react';
import { useAppContext } from '../context.tsx';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function Layout() {
  const { cart, user, logout } = useAppContext();
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const location = useLocation();

  const cartItemsCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Menu', path: '/menu' },
    { name: 'Award', path: '/award' },
    { name: 'Testimoni', path: '/testimonials' },
    { name: 'FAQ', path: '/faq' },
  ];

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  return (
    <div className="min-h-screen flex flex-col bg-slate-200 font-sans text-black">
      {/* Header / Navbar */}
      <header className="sticky top-0 z-50 bg-white border-b-2 border-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            {/* Logo */}
            <div className="flex-shrink-0 flex items-center">
              <Link to="/" className="text-2xl font-bold tracking-tight text-black">
                MieME.
              </Link>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-8">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  className={cn(
                    "text-sm font-medium transition-colors hover:text-black",
                    location.pathname === link.path ? "text-black border-b-2 border-slate-900" : "text-slate-500"
                  )}
                >
                  {link.name}
                </Link>
              ))}
            </nav>

            {/* Icons & Actions */}
            <div className="hidden md:flex items-center space-x-6">
              <Link to="/favorites" className="text-slate-500 hover:text-black transition-colors">
                <Heart className="w-5 h-5" />
              </Link>
              <Link to="/cart" className="text-slate-500 hover:text-black transition-colors relative">
                <ShoppingCart className="w-5 h-5" />
                {cartItemsCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-black text-white text-[10px] font-bold px-1.5 py-0.5 rounded-none">
                    {cartItemsCount}
                  </span>
                )}
              </Link>
              
              {user ? (
                <div className="relative group">
                  <button className="flex items-center space-x-2 text-slate-500 hover:text-black transition-colors">
                    <User className="w-5 h-5" />
                    <span className="text-sm font-medium">{user.name.split(' ')[0]}</span>
                    <ChevronDown className="w-4 h-4" />
                  </button>
                  <div className="absolute right-0 w-48 mt-2 bg-white rounded-none shadow-[8px_8px_0_0_#000] py-1 border-2 border-black opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                    <Link to="/profile" className="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-200">Profile</Link>
                    <Link to="/orders" className="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-200">Riwayat Pesanan</Link>
                    <button onClick={logout} className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-slate-200 flex items-center">
                      <LogOut className="w-4 h-4 mr-2" /> Logout
                    </button>
                  </div>
                </div>
              ) : (
                <Link to="/login" className="text-sm font-medium text-white bg-black hover:bg-slate-800 px-4 py-2 rounded-none transition-colors">
                  Login / Register
                </Link>
              )}
            </div>

            {/* Mobile menu button */}
            <div className="flex items-center md:hidden space-x-4">
              <Link to="/cart" className="text-slate-500 relative">
                <ShoppingCart className="w-5 h-5" />
                {cartItemsCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-black text-white text-[10px] font-bold px-1.5 py-0.5 rounded-none">
                    {cartItemsCount}
                  </span>
                )}
              </Link>
              <button onClick={toggleMenu} className="text-slate-500 hover:text-black">
                {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden border-t-2 border-black bg-white">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  onClick={() => setIsMenuOpen(false)}
                  className="block px-3 py-2 rounded-none text-base font-medium text-black hover:bg-slate-200"
                >
                  {link.name}
                </Link>
              ))}
              
              <div className="border-t-2 border-black pt-4 mt-4">
                {user ? (
                  <>
                    <Link to="/profile" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-none text-base font-medium text-black hover:bg-slate-200">Profile</Link>
                    <Link to="/orders" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-none text-base font-medium text-black hover:bg-slate-200">Riwayat Pesanan</Link>
                    <Link to="/favorites" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-none text-base font-medium text-black hover:bg-slate-200">Favorit</Link>
                    <button onClick={() => { logout(); setIsMenuOpen(false); }} className="w-full text-left px-3 py-2 rounded-none text-base font-medium text-red-600 hover:bg-slate-200">Logout</button>
                  </>
                ) : (
                  <Link to="/login" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-none text-base font-medium text-black hover:bg-slate-200">Login / Register</Link>
                )}
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Main Content Area */}
      <main className="flex-grow">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-black text-slate-300 py-12 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-1">
            <h3 className="text-white text-xl font-bold tracking-tight mb-4">MieME.</h3>
            <p className="text-sm border-t-2 border-slate-800 pt-4 mt-4">
              Pengalaman makan mie premium yang tak terlupakan.
            </p>
          </div>
          <div>
            <h4 className="text-white font-medium mb-4">Navigasi</h4>
            <ul className="space-y-2 text-sm">
              <li><Link to="/about" className="hover:text-white transition-colors">About Us</Link></li>
              <li><Link to="/menu" className="hover:text-white transition-colors">Menu</Link></li>
              <li><Link to="/award" className="hover:text-white transition-colors">Award</Link></li>
              <li><Link to="/faq" className="hover:text-white transition-colors">FAQ</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-medium mb-4">Bantuan</h4>
            <ul className="space-y-2 text-sm">
              <li><Link to="/faq" className="hover:text-white transition-colors">Cara Pesan</Link></li>
              <li><Link to="/faq" className="hover:text-white transition-colors">Pengiriman</Link></li>
              <li><Link to="/faq" className="hover:text-white transition-colors">Pembayaran</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-medium mb-4">Kontak</h4>
            <ul className="space-y-2 text-sm">
              <li>hi@mieme.com</li>
              <li>+62 811 2233 4455</li>
              <li>Jakarta, Indonesia</li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 pt-8 border-t-2 border-slate-800 text-sm text-center">
          &copy; {new Date().getFullYear()} MieME. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
