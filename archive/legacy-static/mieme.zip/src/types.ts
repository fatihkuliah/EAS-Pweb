export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: 'makanan' | 'minuman';
  estimatedTime: string;
  portion: string;
}

export interface CartItem {
  menuItem: MenuItem;
  quantity: number;
}

export interface Order {
  id: string;
  date: string;
  items: CartItem[];
  total: number;
  status: 'Menunggu Pembayaran' | 'Diproses' | 'Dikirim' | 'Selesai';
  paymentReceipt?: string;
  shippingAddress?: string;
  recipientName?: string;
  phoneNumber?: string;
  notes?: string;
}

export interface User {
  name: string;
  email: string;
  phone: string;
  address: string;
  avatar?: string;
}
