import React from 'react';
import { Link } from 'react-router-dom';
import { useAppContext } from '../context.tsx';
import { mockMenu } from '../data.ts';
import { Heart, Trash2 } from 'lucide-react';

export default function Favorites() {
  const { favorites, toggleFavorite, addToCart } = useAppContext();

  const favoriteItems = mockMenu.filter(item => favorites.includes(item.id));

  if (favoriteItems.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-24 text-center">
        <div className="inline-flex items-center justify-center w-24 h-24 bg-rose-50 rounded-none mb-6">
          <Heart className="w-10 h-10 text-rose-300" />
        </div>
        <h2 className="text-2xl font-bold text-black mb-2">Belum ada favorit</h2>
        <p className="text-slate-500 mb-8">Anda belum menambahkan menu apapun ke dalam daftar favorit.</p>
        <Link to="/menu" className="bg-black text-white font-medium px-8 py-3 rounded-none hover:bg-slate-800 transition-colors">
          Jelajahi Menu
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-black mb-8">Daftar Favorit</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {favoriteItems.map((item) => (
          <div key={item.id} className="bg-white rounded-none border-2 border-black overflow-hidden shadow-[4px_4px_0_0_#000] flex flex-col">
            <Link to={`/menu/${item.id}`} className="aspect-video w-full bg-slate-100 relative">
              <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
            </Link>
            <div className="p-4 flex flex-col flex-1">
              <Link to={`/menu/${item.id}`} className="hover:underline">
                <h3 className="font-bold text-black mb-1">{item.name}</h3>
              </Link>
              <p className="text-black font-bold mb-4">Rp {item.price.toLocaleString('id-ID')}</p>
              
              <div className="flex items-center justify-between mt-auto pt-4 border-t-2 border-black">
                <button 
                  onClick={() => addToCart(item, 1)}
                  className="text-sm font-bold text-black bg-slate-100 hover:bg-slate-200 px-4 py-2 rounded-none transition-colors"
                >
                  Masuk Keranjang
                </button>
                <button 
                  onClick={() => toggleFavorite(item.id)}
                  className="text-red-500 hover:bg-red-50 p-2 rounded-none transition-colors"
                  title="Hapus dari Favorit"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
