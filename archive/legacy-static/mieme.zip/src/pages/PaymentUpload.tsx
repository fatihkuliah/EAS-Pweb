import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../context.tsx';
import { Upload, CheckCircle } from 'lucide-react';

export default function PaymentUpload() {
  const navigate = useNavigate();
  const { cart, clearCart, addOrder } = useAppContext();
  
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);

  const checkoutData = JSON.parse(sessionStorage.getItem('checkoutData') || '{}');
  const paymentMethod = sessionStorage.getItem('paymentMethod');
  const total = checkoutData.total || 0;

  if (!total || !paymentMethod) {
    navigate('/cart');
    return null;
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);
      setPreview(URL.createObjectURL(selectedFile));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;

    // Simulate order placement
    const newOrder = {
      id: `ORD-${new Date().toISOString().replace(/\D/g, '').slice(0, 14)}`,
      date: new Date().toISOString(),
      items: [...cart],
      total: total,
      status: 'Menunggu Pembayaran' as const, // Will change to Diproses in real app after verification
      shippingAddress: checkoutData.shippingAddress,
      recipientName: checkoutData.recipientName,
      phoneNumber: checkoutData.phoneNumber,
      notes: checkoutData.notes,
      paymentReceipt: preview || undefined
    };

    addOrder(newOrder);
    clearCart();
    sessionStorage.removeItem('checkoutData');
    sessionStorage.removeItem('paymentMethod');
    
    setIsSuccess(true);
  };

  if (isSuccess) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-24 text-center">
        <div className="inline-flex items-center justify-center w-24 h-24 bg-green-100 rounded-none mb-6">
          <CheckCircle className="w-12 h-12 text-green-600" />
        </div>
        <h1 className="text-3xl font-bold text-black mb-4">Pesanan Berhasil!</h1>
        <p className="text-slate-600 mb-8">
          Terima kasih. Kami telah menerima pesanan dan bukti pembayaran Anda. Kami akan segera memprosesnya.
        </p>
        <button 
          onClick={() => navigate('/orders')}
          className="bg-black text-white font-medium px-8 py-3 rounded-none hover:bg-slate-800 transition-colors"
        >
          Lihat Riwayat Pesanan
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-black mb-8 text-center">Upload Bukti Pembayaran</h1>

      <div className="bg-white p-8 rounded-none border-2 border-black shadow-[4px_4px_0_0_#000] max-w-xl mx-auto">
        <div className="mb-6 pb-6 border-b-2 border-black text-center">
          <p className="text-sm text-slate-500 mb-1">Metode Pembayaran</p>
          <p className="font-bold text-black">{paymentMethod}</p>
          <p className="text-sm text-slate-500 mt-4 mb-1">Silakan transfer sesuai nominal</p>
          <p className="text-2xl font-bold text-black">Rp {total.toLocaleString('id-ID')}</p>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="mb-6">
            <label className="block text-sm font-medium text-slate-700 mb-2">Upload Bukti (JPG, JPEG, PNG)</label>
            <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-black border-dashed rounded-none relative hover:bg-slate-200 transition-colors">
              <div className="space-y-1 text-center">
                {preview ? (
                  <div className="mb-4">
                    <img src={preview} alt="Preview" className="mx-auto h-48 object-contain rounded" />
                  </div>
                ) : (
                  <Upload className="mx-auto h-12 w-12 text-slate-400" />
                )}
                <div className="flex text-sm text-slate-600 justify-center">
                  <label htmlFor="file-upload" className="relative cursor-pointer bg-white rounded-none font-medium text-black hover:text-slate-700 focus-within:outline-none">
                    <span>{preview ? 'Ganti file' : 'Pilih file'}</span>
                    <input id="file-upload" name="file-upload" type="file" accept=".jpg,.jpeg,.png" className="sr-only" onChange={handleFileChange} required />
                  </label>
                </div>
                {!preview && <p className="text-xs text-slate-500">PNG, JPG up to 5MB</p>}
              </div>
            </div>
          </div>

          <button 
            type="submit"
            disabled={!file}
            className="w-full bg-black text-white font-bold py-3 rounded-none hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            Kirim Pembayaran
          </button>
        </form>
      </div>
    </div>
  );
}
