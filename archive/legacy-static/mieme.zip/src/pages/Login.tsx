import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAppContext } from '../context.tsx';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login } = useAppContext();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate login
    login(email);
    navigate('/');
  };

  return (
    <div className="max-w-md mx-auto px-4 py-24">
      <div className="bg-white p-8 rounded-none border-2 border-black shadow-[4px_4px_0_0_#000]">
        <h1 className="text-3xl font-bold text-black mb-2 text-center">Selamat Datang</h1>
        <p className="text-slate-500 text-center mb-8">Masuk ke akun MieME Anda.</p>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Email</label>
            <input 
              type="email" 
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-2 border-2 border-black rounded-none focus:ring-slate-900 focus:border-slate-900"
              placeholder="email@contoh.com"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Password</label>
            <input 
              type="password" 
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-2 border-2 border-black rounded-none focus:ring-slate-900 focus:border-slate-900"
              placeholder="••••••••"
            />
          </div>

          <button 
            type="submit"
            className="w-full bg-black text-white font-bold py-3 rounded-none hover:bg-slate-800 transition-colors"
          >
            Masuk
          </button>
        </form>

        <p className="text-center text-sm text-slate-600 mt-8">
          Belum punya akun?{' '}
          <Link to="/register" className="font-semibold text-black hover:underline">
            Daftar Sekarang
          </Link>
        </p>
      </div>
    </div>
  );
}
