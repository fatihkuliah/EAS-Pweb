import React from 'react';
import { Link } from 'react-router-dom';
import { mockMenu } from '../data.ts';

export default function Home() {
  return (
    <div className="flex flex-col gap-16 pb-16">
      {/* Hero Section */}
      <section className="bg-black text-white py-24 px-4 sm:px-6 lg:px-8 text-center flex flex-col items-center justify-center min-h-[60vh]">
        <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-6 max-w-4xl leading-tight">
          Sajian Mie Premium untuk Pecinta Rasa Sejati
        </h1>
        <p className="text-lg md:text-xl text-slate-300 mb-10 max-w-2xl">
          MieME menghadirkan pengalaman kuliner mie modern dengan bahan berkualitas tinggi, 
          tekstur mie artisan, dan kaldu otentik yang kaya rasa.
        </p>
        <Link 
          to="/menu" 
          className="bg-white text-black font-medium px-8 py-3 rounded-none hover:bg-slate-100 transition-colors shadow-[8px_8px_0_0_#000]"
        >
          Order Sekarang
        </Link>
      </section>

      {/* Featured Menu Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="flex justify-between items-end mb-8 border-b-2 border-black pb-4">
          <div>
            <h2 className="text-2xl font-bold text-black">Featured Menu</h2>
            <p className="text-slate-500 mt-1">Hidangan favorit pelanggan kami.</p>
          </div>
          <Link to="/menu" className="text-sm font-medium text-black hover:underline">
            Lihat Semua &rarr;
          </Link>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {mockMenu.slice(0, 3).map((item) => (
            <div key={item.id} className="bg-white rounded-none shadow-[4px_4px_0_0_#000] border-2 border-black overflow-hidden hover:shadow-[6px_6px_0_0_#000] transition-shadow group flex flex-col">
              <div className="aspect-video w-full bg-slate-100 relative overflow-hidden">
                <img 
                  src={item.image} 
                  alt={item.name} 
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-2 right-2 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-none text-xs font-semibold shadow-[4px_4px_0_0_#000]">
                  {item.category.toUpperCase()}
                </div>
              </div>
              <div className="p-5 flex flex-col flex-grow">
                <h3 className="text-lg font-bold text-black mb-1">{item.name}</h3>
                <p className="text-sm text-slate-600 line-clamp-2 mb-4 flex-grow">{item.description}</p>
                <div className="flex items-center justify-between mt-auto pt-4 border-t-2 border-black">
                  <span className="font-bold text-black">Rp {item.price.toLocaleString('id-ID')}</span>
                  <Link to={`/menu/${item.id}`} className="text-sm font-medium bg-slate-100 text-black px-3 py-1.5 rounded-none hover:bg-slate-200 transition-colors">
                    Detail
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* About Preview Section */}
      <section className="bg-white py-16 px-4 sm:px-6 lg:px-8 border-y border-black">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center gap-12">
          <div className="w-full md:w-1/2 aspect-[4/3] bg-slate-100 rounded-none overflow-hidden">
            <img src="https://images.unsplash.com/photo-1552611052-33e04de081de?auto=format&fit=crop&q=80&w=1000" alt="Mie preparation" className="w-full h-full object-cover" />
          </div>
          <div className="w-full md:w-1/2">
            <h2 className="text-3xl font-bold text-black mb-4">Filosofi MieME</h2>
            <p className="text-slate-600 mb-6 leading-relaxed">
              Kami percaya bahwa semangkuk mie bukan sekadar makanan, melainkan pengalaman yang menenangkan jiwa. 
              Dibuat setiap hari menggunakan tepung berkualitas tinggi tanpa pengawet buatan.
            </p>
            <Link to="/about" className="inline-block border-2 border-black text-black font-medium px-6 py-2 rounded-none hover:bg-slate-200 transition-colors">
              Kenali Kami Lebih Dekat
            </Link>
          </div>
        </div>
      </section>

    </div>
  );
}
