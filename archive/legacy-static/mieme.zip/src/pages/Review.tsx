import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAppContext } from '../context.tsx';
import { Star, Upload, CheckCircle } from 'lucide-react';

export default function Review() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { orders } = useAppContext();
  
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  const order = orders.find(o => o.id === id);

  if (!order || order.status !== 'Selesai') {
    return <div className="p-16 text-center">Pesanan tidak ditemukan atau belum selesai.</div>;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (rating === 0) {
      alert('Silakan berikan rating bintang terlebih dahulu.');
      return;
    }
    // Simulate submitting review
    setIsSuccess(true);
    setTimeout(() => {
      navigate(`/orders/${order.id}`);
    }, 2000);
  };

  if (isSuccess) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-24 text-center">
        <div className="inline-flex items-center justify-center w-24 h-24 bg-green-100 rounded-none mb-6">
          <CheckCircle className="w-12 h-12 text-green-600" />
        </div>
        <h1 className="text-3xl font-bold text-black mb-4">Terima Kasih!</h1>
        <p className="text-slate-600 mb-8">
          Ulasan Anda sangat berarti bagi peningkatan kualitas layanan kami.
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-black mb-2 text-center">Beri Ulasan</h1>
      <p className="text-slate-500 text-center mb-8">Pesanan: {order.id}</p>

      <form onSubmit={handleSubmit} className="bg-white p-8 rounded-none border-2 border-black shadow-[4px_4px_0_0_#000]">
        <div className="mb-8">
          <label className="block text-center font-bold text-black mb-4 text-lg">Bagaimana kualitas makanan kami?</label>
          <div className="flex justify-center gap-2">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                className="focus:outline-none transition-transform hover:scale-110"
                onMouseEnter={() => setHoverRating(star)}
                onMouseLeave={() => setHoverRating(0)}
                onClick={() => setRating(star)}
              >
                <Star 
                  className={`w-10 h-10 ${
                    star <= (hoverRating || rating) 
                      ? 'fill-yellow-400 text-yellow-400' 
                      : 'text-slate-200'
                  }`} 
                />
              </button>
            ))}
          </div>
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-slate-700 mb-2">Ceritakan pengalaman Anda</label>
          <textarea 
            rows={4}
            required
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            className="w-full px-4 py-2 border-2 border-black rounded-none focus:ring-slate-900 focus:border-slate-900"
            placeholder="Rasa makanan enak, pengiriman cepat..."
          />
        </div>

        <div className="mb-8">
          <label className="block text-sm font-medium text-slate-700 mb-2">Upload Foto <span className="text-slate-400 font-normal">(Opsional)</span></label>
          <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-black border-dashed rounded-none hover:bg-slate-200 cursor-pointer">
            <div className="space-y-1 text-center">
              <Upload className="mx-auto h-8 w-8 text-slate-400" />
              <div className="flex text-sm text-slate-600 justify-center">
                <span className="relative rounded-none font-medium text-black">
                  Pilih foto makanan
                </span>
              </div>
            </div>
          </div>
        </div>

        <button 
          type="submit"
          className="w-full bg-black text-white font-bold py-3 rounded-none hover:bg-slate-800 transition-colors"
        >
          Kirim Ulasan
        </button>
      </form>
    </div>
  );
}
