import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Payment() {
  const navigate = useNavigate();
  const [selectedMethod, setSelectedMethod] = useState('');

  const checkoutData = JSON.parse(sessionStorage.getItem('checkoutData') || '{}');
  const total = checkoutData.total || 0;

  if (!total) {
    navigate('/cart');
    return null;
  }

  const methods = [
    { id: 'transfer', name: 'Transfer Bank (BCA, Mandiri, BNI)', type: 'Transfer Bank' },
    { id: 'ewallet', name: 'E-Wallet (GoPay, OVO, Dana)', type: 'E-Wallet' },
    { id: 'va', name: 'Virtual Account', type: 'Virtual Account' },
    { id: 'qris', name: 'QRIS', type: 'QRIS' },
  ];

  const handleContinue = () => {
    if (selectedMethod) {
      sessionStorage.setItem('paymentMethod', selectedMethod);
      navigate('/payment/upload');
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-black mb-8 text-center">Pilih Metode Pembayaran</h1>

      <div className="bg-slate-200 p-6 rounded-none border-2 border-black mb-8 text-center">
        <h2 className="text-sm font-medium text-slate-500 mb-2">Total Tagihan</h2>
        <div className="text-3xl font-bold text-black">Rp {total.toLocaleString('id-ID')}</div>
      </div>

      <div className="space-y-4 mb-8">
        {methods.map((method) => (
          <label 
            key={method.id} 
            className={`block p-4 border-2 rounded-none cursor-pointer transition-colors ${
              selectedMethod === method.name 
                ? 'border-slate-900 bg-slate-200 ring-1 ring-slate-900' 
                : 'border-black bg-white hover:border-black'
            }`}
          >
            <div className="flex items-center">
              <input 
                type="radio" 
                name="paymentMethod" 
                value={method.name}
                checked={selectedMethod === method.name}
                onChange={(e) => setSelectedMethod(e.target.value)}
                className="h-4 w-4 text-black border-black focus:ring-slate-900"
              />
              <div className="ml-4">
                <span className="block font-medium text-black">{method.type}</span>
                <span className="block text-sm text-slate-500">{method.name}</span>
              </div>
            </div>
          </label>
        ))}
      </div>

      <button 
        onClick={handleContinue}
        disabled={!selectedMethod}
        className="w-full bg-black text-white font-bold py-3 rounded-none hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
      >
        Lanjut
      </button>
    </div>
  );
}
