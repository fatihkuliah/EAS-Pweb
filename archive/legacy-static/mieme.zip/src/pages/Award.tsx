import React from 'react';
import { Award as AwardIcon, Star, ShieldCheck } from 'lucide-react';

export default function Award() {
  const awards = [
    {
      title: "Best Regional Noodle House 2022",
      organization: "Culinary Excellence Awards",
      description: "Penghargaan atas inovasi rasa dan konsistensi kualitas produk selama 3 tahun berturut-turut.",
      icon: <AwardIcon className="w-8 h-8 text-slate-700" />
    },
    {
      title: "Top 10 Asian Restaurants",
      organization: "Foodies Choice Magazine",
      description: "Masuk dalam jajaran restoran dengan rating pelanggan tertinggi versi pembaca majalah tahun 2023.",
      icon: <Star className="w-8 h-8 text-slate-700" />
    },
    {
      title: "Sertifikasi Halal MUI & BPOM",
      organization: "MUI & BPOM RI",
      description: "Seluruh proses produksi dan bahan baku telah disertifikasi halal dan terstandarisasi keamanan pangan.",
      icon: <ShieldCheck className="w-8 h-8 text-slate-700" />
    }
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 py-16">
      <div className="text-center mb-16">
        <h1 className="text-4xl font-bold mb-4">Penghargaan & Sertifikasi</h1>
        <p className="text-slate-600 max-w-2xl mx-auto">
          Komitmen kami terhadap kualitas tidak hanya dirasakan oleh hati pelanggan, tetapi juga diakui oleh lembaga kuliner ternama.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        {awards.map((award, idx) => (
          <div key={idx} className="bg-white p-8 rounded-none border-2 border-black shadow-[4px_4px_0_0_#000] text-center flex flex-col items-center">
            <div className="w-16 h-16 bg-slate-200 rounded-none flex items-center justify-center mb-4">
              {award.icon}
            </div>
            <h3 className="text-lg font-bold text-black mb-2">{award.title}</h3>
            <p className="text-sm font-medium text-slate-500 mb-4">{award.organization}</p>
            <p className="text-sm text-slate-600">{award.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
