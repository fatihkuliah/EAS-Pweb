import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAppContext } from '../context.tsx';
import { Trash2, Minus, Plus, ShoppingBag } from 'lucide-react';

export default function Cart() {
  const { cart, updateQuantity, removeFromCart } = useAppContext();
  const navigate = useNavigate();

  const subtotal = cart.reduce((acc, item) => acc + (item.menuItem.price * item.quantity), 0);

  if (cart.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-24 text-center">
        <div className="inline-flex w-24 h-24 bg-slate-100 rounded-none items-center justify-center mb-6">
          <ShoppingBag className="w-10 h-10 text-slate-400" />
        </div>
        <h2 className="text-2xl font-bold text-black mb-2">Keranjang Belanja Kosong</h2>
        <p className="text-slate-500 mb-8">Anda belum menambahkan menu ke keranjang.</p>
        <Link to="/menu" className="bg-black text-white font-medium px-8 py-3 rounded-none hover:bg-slate-800 transition-colors">
          Lihat Menu
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-black mb-8">Keranjang Belanja</h1>

      <div className="flex flex-col lg:flex-row gap-8">
        <div className="lg:w-2/3 flex flex-col gap-4">
          {cart.map((item) => (
            <div key={item.menuItem.id} className="flex gap-4 bg-white p-4 rounded-none border-2 border-black">
              <img 
                src={item.menuItem.image} 
                alt={item.menuItem.name} 
                className="w-24 h-24 md:w-32 md:h-32 object-cover rounded-none bg-slate-100"
              />
              <div className="flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="font-bold text-lg text-black">{item.menuItem.name}</h3>
                  <p className="text-slate-500 font-medium">Rp {item.menuItem.price.toLocaleString('id-ID')}</p>
                </div>
                <div className="flex items-center justify-between mt-4">
                  <div className="flex items-center border-2 border-black rounded-none">
                    <button 
                      onClick={() => updateQuantity(item.menuItem.id, item.quantity - 1)}
                      className="px-3 py-1 hover:bg-slate-200 transition-colors"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="w-10 text-center font-medium">{item.quantity}</span>
                    <button 
                      onClick={() => updateQuantity(item.menuItem.id, item.quantity + 1)}
                      className="px-3 py-1 hover:bg-slate-200 transition-colors"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                  <button 
                    onClick={() => removeFromCart(item.menuItem.id)}
                    className="text-red-500 hover:bg-red-50 p-2 rounded-none transition-colors"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="lg:w-1/3">
          <div className="bg-slate-200 p-6 rounded-none border-2 border-black sticky top-24">
            <h3 className="text-lg font-bold text-black mb-6">Ringkasan Belanja</h3>
            
            <div className="space-y-3 mb-6 pb-6 border-b-2 border-black">
              <div className="flex justify-between text-slate-600">
                <span>Total Item</span>
                <span>{cart.reduce((acc, item) => acc + item.quantity, 0)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Subtotal</span>
                <span>Rp {subtotal.toLocaleString('id-ID')}</span>
              </div>
            </div>
            
            <div className="flex justify-between text-lg font-bold text-black mb-6">
              <span>Total Harga</span>
              <span>Rp {subtotal.toLocaleString('id-ID')}</span>
            </div>
            
            <button 
              onClick={() => navigate('/checkout')}
              className="w-full bg-black text-white font-bold py-3 rounded-none hover:bg-slate-800 transition-colors"
            >
              Lanjut Checkout
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
