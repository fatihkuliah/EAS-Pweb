import React from 'react';

export default function About() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold mb-8 text-center">Tentang MieME</h1>
      
      <div className="aspect-video w-full bg-slate-100 rounded-none overflow-hidden mb-12">
        <img 
          src="https://images.unsplash.com/photo-1552611052-33e04de081de?auto=format&fit=crop&q=80&w=1200" 
          alt="Kitchen" 
          className="w-full h-full object-cover"
        />
      </div>

      <div className="space-y-12 text-slate-700 leading-relaxed">
        <section>
          <h2 className="text-2xl font-bold mb-4 text-black">Cerita Kami</h2>
          <p className="mb-4">
            MieME berawal dari kecintaan kami terhadap mie nusantara dan asia. Berdiri sejak tahun 2018, 
            kami memulai perjalanan dari sebuah gerai kecil dengan mimpi besar: menyajikan mie artisan 
            berkualitas premium untuk semua kalangan dengan harga yang masuk akal.
          </p>
          <p>
            Nama "MieME" sendiri diambil dari kata "Mie" dan "Me" (Saya), mengisyaratkan bahwa setiap mangkuk
            mie kami dibuat secara personal seolah-olah kami memasaknya untuk diri kami sendiri.
          </p>
        </section>

        <section className="grid md:grid-cols-2 gap-8 bg-slate-200 p-8 rounded-none border-2 border-black">
          <div>
            <h3 className="text-xl font-bold mb-3 text-black">Bahan Premium</h3>
            <p className="text-sm">
              Kami secara ketat menyeleksi pemasok lokal dan internasional untuk memastikan gandum, 
              daging, dan rempah-rempah yang kami gunakan ada pada kualitas puncak. Tanpa kompromi.
            </p>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-3 text-black">100% Fresh Dibuat</h3>
            <p className="text-sm">
              Mie kami diproduksi setiap pagi untuk menjaga kekenyalan (al dente) dan kesegarannya. 
              Tidak ada adonan sisa hari kemarin di dapur kami.
            </p>
          </div>
        </section>
      </div>
    </div>
  );
}
