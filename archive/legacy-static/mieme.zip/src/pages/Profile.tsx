import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../context.tsx';
import { User, Camera } from 'lucide-react';

export default function Profile() {
  const { user, updateUser, logout } = useAppContext();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: user?.name || '',
    phone: user?.phone || '',
    address: user?.address || ''
  });
  
  const [isEditing, setIsEditing] = useState(false);
  const [avatar, setAvatar] = useState(user?.avatar || null);

  if (!user) {
    navigate('/login');
    return null;
  }

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateUser({ ...formData, avatar: avatar || undefined });
    setIsEditing(false);
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setAvatar(URL.createObjectURL(file));
      // In a real app, you'd upload this to a server
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-black mb-8">Profil Pengguna</h1>

      <div className="bg-white p-8 rounded-none border-2 border-black shadow-[4px_4px_0_0_#000]">
        
        {/* Avatar Section */}
        <div className="flex flex-col items-center mb-8 pb-8 border-b-2 border-black">
          <div className="relative mb-4 group">
            <div className="w-24 h-24 rounded-none bg-slate-100 flex items-center justify-center overflow-hidden border-2 border-black">
              {avatar ? (
                <img src={avatar} alt="Profile" className="w-full h-full object-cover" />
              ) : (
                <User className="w-12 h-12 text-slate-400" />
              )}
            </div>
            
            {isEditing && (
              <label className="absolute bottom-0 right-0 bg-black text-white p-2 rounded-none cursor-pointer hover:bg-slate-800 transition-colors shadow-[4px_4px_0_0_#000]">
                <Camera className="w-4 h-4" />
                <input type="file" className="hidden" accept="image/*" onChange={handleAvatarChange} />
              </label>
            )}
          </div>
          <h2 className="text-xl font-bold text-black">{user.name}</h2>
          <p className="text-slate-500">{user.email}</p>
        </div>

        {/* Info Section */}
        <form onSubmit={handleSave}>
          <div className="space-y-6 max-w-xl mx-auto">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Nama Lengkap</label>
              <input 
                type="text" 
                disabled={!isEditing}
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                className="w-full px-4 py-2 border-2 border-black rounded-none disabled:bg-slate-200 focus:ring-slate-900 focus:border-slate-900"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Nomor Telepon</label>
              <input 
                type="tel" 
                disabled={!isEditing}
                value={formData.phone}
                onChange={(e) => setFormData({...formData, phone: e.target.value})}
                className="w-full px-4 py-2 border-2 border-black rounded-none disabled:bg-slate-200 focus:ring-slate-900 focus:border-slate-900"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Alamat Utama</label>
              <textarea 
                disabled={!isEditing}
                rows={3}
                value={formData.address}
                onChange={(e) => setFormData({...formData, address: e.target.value})}
                className="w-full px-4 py-2 border-2 border-black rounded-none disabled:bg-slate-200 focus:ring-slate-900 focus:border-slate-900"
              />
            </div>

            <div className="flex gap-4 pt-4">
              {isEditing ? (
                <>
                  <button 
                    type="button"
                    onClick={() => {
                      setIsEditing(false);
                      setFormData({ name: user.name, phone: user.phone, address: user.address });
                      setAvatar(user.avatar || null);
                    }}
                    className="flex-1 bg-white border-2 border-black text-slate-700 py-2 rounded-none hover:bg-slate-200 transition-colors"
                  >
                    Batal
                  </button>
                  <button 
                    type="submit"
                    className="flex-1 bg-black text-white font-medium py-2 rounded-none hover:bg-slate-800 transition-colors"
                  >
                    Simpan Perubahan
                  </button>
                </>
              ) : (
                <>
                  <button 
                    type="button"
                    onClick={() => setIsEditing(true)}
                    className="flex-1 bg-black text-white font-medium py-2 rounded-none hover:bg-slate-800 transition-colors"
                  >
                    Edit Profil
                  </button>
                  <button 
                    type="button"
                    onClick={() => {
                      logout();
                      navigate('/');
                    }}
                    className="flex-none bg-white border-2 border-red-200 text-red-600 font-medium px-6 py-2 rounded-none hover:bg-red-50 transition-colors"
                  >
                    Logout
                  </button>
                </>
              )}
            </div>
          </div>
        </form>

      </div>
    </div>
  );
}
