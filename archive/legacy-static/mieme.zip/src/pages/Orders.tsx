import React from 'react';
import { Link } from 'react-router-dom';
import { useAppContext } from '../context.tsx';
import { Download } from 'lucide-react';

export default function Orders() {
  const { orders } = useAppContext();

  const handleExportCSV = () => {
    // Basic CSV export logic
    const headers = ['Tanggal', 'Nomor Pesanan', 'Total Item', 'Total Pembayaran', 'Status'];
    const rows = orders.map(order => [
      new Date(order.date).toLocaleDateString('id-ID'),
      order.id,
      order.items.reduce((acc, item) => acc + item.quantity, 0).toString(),
      order.total.toString(),
      order.status
    ]);
    
    const csvContent = "data:text/csv;charset=utf-8," 
      + headers.join(',') + '\n'
      + rows.map(e => e.join(',')).join('\n');
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "riwayat_pesanan_mieme.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'Menunggu Pembayaran': return 'bg-yellow-100 text-yellow-800';
      case 'Diproses': return 'bg-blue-100 text-blue-800';
      case 'Dikirim': return 'bg-purple-100 text-purple-800';
      case 'Selesai': return 'bg-green-100 text-green-800';
      default: return 'bg-slate-100 text-slate-800';
    }
  };

  if (orders.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-24 text-center">
        <h2 className="text-2xl font-bold text-black mb-2">Belum ada pesanan</h2>
        <p className="text-slate-500 mb-8">Anda belum pernah melakukan pemesanan.</p>
        <Link to="/menu" className="bg-black text-white font-medium px-8 py-3 rounded-none hover:bg-slate-800 transition-colors">
          Mulai Pesan
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-12">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-black">Riwayat Pesanan</h1>
        <button 
          onClick={handleExportCSV}
          className="flex items-center text-sm font-medium border-2 border-black bg-white px-4 py-2 rounded-none hover:bg-slate-200 transition-colors"
        >
          <Download className="w-4 h-4 mr-2" /> Export CSV
        </button>
      </div>

      <div className="space-y-6">
        {orders.map((order) => (
          <div key={order.id} className="bg-white p-6 rounded-none border-2 border-black shadow-[4px_4px_0_0_#000] flex flex-col md:flex-row justify-between gap-6">
            <div className="flex-1">
              <div className="flex items-center gap-4 mb-4">
                <span className="font-mono text-sm font-semibold text-black">{order.id}</span>
                <span className="text-sm text-slate-500">{new Date(order.date).toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
                <span className={`text-xs font-bold px-2.5 py-1 rounded-none ${getStatusColor(order.status)}`}>
                  {order.status}
                </span>
              </div>
              
              <div className="space-y-2 mb-4">
                {order.items.map((item, idx) => (
                  <div key={idx} className="flex gap-4 items-center">
                    <img src={item.menuItem.image} alt="" className="w-12 h-12 rounded object-cover" />
                    <div>
                      <p className="text-sm font-medium text-black">{item.menuItem.name}</p>
                      <p className="text-xs text-slate-500">{item.quantity} x {item.menuItem.price.toLocaleString('id-ID')}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="flex flex-col justify-between items-end border-t-2 md:border-t-0 md:border-l-2 border-black pt-4 md:pt-0 md:pl-6 min-w-[200px]">
              <div className="text-right w-full mb-4">
                <p className="text-sm text-slate-500 mb-1">Total Belanja</p>
                <p className="text-xl font-bold text-black">Rp {order.total.toLocaleString('id-ID')}</p>
              </div>
              <Link 
                to={`/orders/${order.id}`}
                className="w-full text-center bg-white border-2 border-black text-black font-medium px-4 py-2 rounded-none hover:bg-slate-200 transition-colors"
              >
                Detail Pesanan
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
