import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { mockMenu } from '../data.ts';
import { useAppContext } from '../context.tsx';
import { Heart, Minus, Plus, ArrowLeft, Clock, Users } from 'lucide-react';

export default function MenuDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addToCart, toggleFavorite, favorites } = useAppContext();
  const [quantity, setQuantity] = useState(1);

  const item = mockMenu.find(m => m.id === id);

  if (!item) {
    return <div className="p-16 text-center">Menu tidak ditemukan.</div>;
  }

  const isFavorite = favorites.includes(item.id);

  const handleAddCart = () => {
    addToCart(item, quantity);
    navigate('/cart');
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <button 
        onClick={() => navigate(-1)} 
        className="flex items-center text-sm font-medium text-slate-500 hover:text-black mb-8 transition-colors"
      >
        <ArrowLeft className="w-4 h-4 mr-2" /> Kembali
      </button>

      <div className="grid md:grid-cols-2 gap-12 bg-white p-6 md:p-10 rounded-none border-2 border-black shadow-[4px_4px_0_0_#000]">
        {/* Image Section */}
        <div className="aspect-square bg-slate-100 rounded-none overflow-hidden relative">
          <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
          <button 
            onClick={() => toggleFavorite(item.id)}
            className="absolute top-4 right-4 p-3 bg-white/80 backdrop-blur-sm rounded-none hover:bg-white transition-colors shadow-[4px_4px_0_0_#000]"
          >
            <Heart className={`w-6 h-6 ${isFavorite ? 'fill-red-500 text-red-500' : 'text-slate-600'}`} />
          </button>
        </div>

        {/* Details Section */}
        <div className="flex flex-col">
          <div className="uppercase tracking-wider text-xs font-semibold text-slate-500 mb-2">
            {item.category}
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-black mb-4">{item.name}</h1>
          <p className="text-slate-600 text-lg mb-6 leading-relaxed">
            {item.description}
          </p>

          <div className="flex gap-6 mb-8 pb-8 border-b-2 border-black">
            <div className="flex items-center text-slate-700">
              <Clock className="w-5 h-5 mr-2 text-slate-400" />
              <span className="font-medium">{item.estimatedTime}</span>
            </div>
            <div className="flex items-center text-slate-700">
              <Users className="w-5 h-5 mr-2 text-slate-400" />
              <span className="font-medium">{item.portion}</span>
            </div>
          </div>

          <div className="mb-8">
            <div className="text-3xl font-bold text-black mb-6">
              Rp {(item.price * quantity).toLocaleString('id-ID')}
            </div>
            
            <div className="flex items-center gap-4">
              <div className="flex items-center border-2 border-black rounded-none h-12">
                <button 
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-4 text-slate-500 hover:text-black h-full flex items-center justify-center transition-colors"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="w-12 text-center font-semibold text-lg">{quantity}</span>
                <button 
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-4 text-slate-500 hover:text-black h-full flex items-center justify-center transition-colors"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              
              <button 
                onClick={handleAddCart}
                className="flex-1 bg-black hover:bg-slate-800 text-white font-medium h-12 rounded-none transition-colors"
              >
                Tambah ke Keranjang
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
