import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../context.tsx';

export default function Checkout() {
  const { cart, user } = useAppContext();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    recipientName: '',
    phoneNumber: '',
    shippingAddress: '',
    notes: ''
  });

  useEffect(() => {
    if (cart.length === 0) {
      navigate('/cart');
    }
    if (user) {
      setFormData(prev => ({
        ...prev,
        recipientName: user.name,
        phoneNumber: user.phone,
        shippingAddress: user.address,
      }));
    }
  }, [cart, user, navigate]);

  const subtotal = cart.reduce((acc, item) => acc + (item.menuItem.price * item.quantity), 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate saving checkout data to session to be used in payment page
    sessionStorage.setItem('checkoutData', JSON.stringify({ ...formData, total: subtotal }));
    navigate('/payment');
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-black mb-8">Checkout</h1>

      <div className="flex flex-col lg:flex-row gap-12">
        <div className="lg:w-2/3">
          <form id="checkout-form" onSubmit={handleSubmit} className="bg-white p-6 md:p-8 rounded-none border-2 border-black">
            <h2 className="text-xl font-bold text-black mb-6">Informasi Pengiriman</h2>
            
            <div className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Nama Penerima</label>
                  <input 
                    type="text" 
                    required
                    value={formData.recipientName}
                    onChange={(e) => setFormData({...formData, recipientName: e.target.value})}
                    className="w-full px-4 py-2 border-2 border-black rounded-none focus:ring-slate-900 focus:border-slate-900"
                    placeholder="Contoh: Budi Santoso"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Nomor Telepon</label>
                  <input 
                    type="tel" 
                    required
                    value={formData.phoneNumber}
                    onChange={(e) => setFormData({...formData, phoneNumber: e.target.value})}
                    className="w-full px-4 py-2 border-2 border-black rounded-none focus:ring-slate-900 focus:border-slate-900"
                    placeholder="Contoh: 081234567890"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Alamat Lengkap</label>
                <textarea 
                  required
                  rows={3}
                  value={formData.shippingAddress}
                  onChange={(e) => setFormData({...formData, shippingAddress: e.target.value})}
                  className="w-full px-4 py-2 border-2 border-black rounded-none focus:ring-slate-900 focus:border-slate-900"
                  placeholder="Nama jalan, gedung, no rumah/blok, kecamatan, kota, kode pos."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Catatan Pesanan <span className="text-slate-400 font-normal">(Opsional)</span></label>
                <textarea 
                  rows={2}
                  value={formData.notes}
                  onChange={(e) => setFormData({...formData, notes: e.target.value})}
                  className="w-full px-4 py-2 border-2 border-black rounded-none focus:ring-slate-900 focus:border-slate-900"
                  placeholder="Contoh: Sambal dipisah, minta sumpit kayu."
                />
              </div>
            </div>
          </form>
        </div>

        <div className="lg:w-1/3">
          <div className="bg-slate-200 p-6 rounded-none border-2 border-black sticky top-24">
            <h3 className="text-lg font-bold text-black mb-6">Ringkasan Pesanan</h3>
            
            <div className="space-y-4 mb-6 max-h-60 overflow-y-auto pr-2">
              {cart.map((item) => (
                <div key={item.menuItem.id} className="flex justify-between items-start text-sm">
                  <div className="flex-1 pr-4">
                    <span className="font-medium text-black">{item.menuItem.name}</span>
                    <div className="text-slate-500">{item.quantity} x {item.menuItem.price.toLocaleString('id-ID')}</div>
                  </div>
                  <span className="font-medium text-black text-right whitespace-nowrap">
                    Rp {(item.menuItem.price * item.quantity).toLocaleString('id-ID')}
                  </span>
                </div>
              ))}
            </div>

            <div className="border-t-2 border-black pt-4 mb-6">
              <div className="flex justify-between text-lg font-bold text-black">
                <span>Total Pembayaran</span>
                <span>Rp {subtotal.toLocaleString('id-ID')}</span>
              </div>
            </div>

            <button 
              type="submit"
              form="checkout-form"
              className="w-full bg-black text-white font-bold py-3 rounded-none hover:bg-slate-800 transition-colors"
            >
              Pilih Pembayaran
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
