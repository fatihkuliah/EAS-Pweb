import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAppContext } from '../context.tsx';
import { ArrowLeft, FileText, Star } from 'lucide-react';

export default function OrderDetail() {
  const { id } = useParams<{ id: string }>();
  const { orders } = useAppContext();

  const order = orders.find(o => o.id === id);

  if (!order) {
    return <div className="p-16 text-center">Pesanan tidak ditemukan.</div>;
  }

  const handleDownloadInvoice = () => {
    // In a real app, this would generate and download a PDF
    alert('Fungsi download PDF Invoice akan berjalan di sini.');
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <Link to="/orders" className="flex items-center text-sm font-medium text-slate-500 hover:text-black mb-8 transition-colors">
        <ArrowLeft className="w-4 h-4 mr-2" /> Kembali ke Riwayat Pesanan
      </Link>

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold text-black mb-2">Detail Pesanan</h1>
          <p className="font-mono text-slate-500">{order.id} • {new Date(order.date).toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</p>
        </div>
        <div className="flex gap-4 w-full md:w-auto">
          <button 
            onClick={handleDownloadInvoice}
            className="flex-1 md:flex-none flex justify-center items-center gap-2 bg-white border-2 border-black text-black font-medium px-4 py-2 rounded-none hover:bg-slate-200 transition-colors"
          >
            <FileText className="w-4 h-4" /> Download Invoice
          </button>
          {order.status === 'Selesai' && (
            <Link 
              to={`/orders/${order.id}/review`}
              className="flex-1 md:flex-none flex justify-center items-center gap-2 bg-black text-white font-medium px-4 py-2 rounded-none hover:bg-slate-800 transition-colors"
            >
              <Star className="w-4 h-4" /> Beri Ulasan
            </Link>
          )}
        </div>
      </div>

      <div className="bg-white rounded-none border-2 border-black shadow-[4px_4px_0_0_#000] overflow-hidden mb-8">
        <div className="p-6 border-b-2 border-black bg-slate-200">
          <p className="text-sm text-slate-500 font-medium mb-1">Status Pesanan</p>
          <p className="text-lg font-bold text-black">{order.status}</p>
        </div>
        
        <div className="p-6">
          <h3 className="font-bold text-black mb-4">Rincian Menu</h3>
          <div className="space-y-4 mb-6">
            {order.items.map((item, idx) => (
              <div key={idx} className="flex justify-between items-center pb-4 border-b-2 border-black last:border-0 last:pb-0">
                <div className="flex items-center gap-4">
                  <img src={item.menuItem.image} alt={item.menuItem.name} className="w-16 h-16 rounded object-cover bg-slate-100" />
                  <div>
                    <p className="font-medium text-black">{item.menuItem.name}</p>
                    <p className="text-sm text-slate-500">{item.quantity} x Rp {item.menuItem.price.toLocaleString('id-ID')}</p>
                  </div>
                </div>
                <div className="font-medium text-black">
                  Rp {(item.quantity * item.menuItem.price).toLocaleString('id-ID')}
                </div>
              </div>
            ))}
          </div>

          <div className="border-t-2 border-black pt-4 flex justify-between items-center">
            <span className="font-bold text-black">Total Pembayaran</span>
            <span className="text-xl font-bold text-black">Rp {order.total.toLocaleString('id-ID')}</span>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="bg-white p-6 rounded-none border-2 border-black shadow-[4px_4px_0_0_#000]">
          <h3 className="font-bold text-black mb-4">Informasi Pengiriman</h3>
          <div className="space-y-3 text-sm">
            <div>
              <p className="text-slate-500 mb-1">Penerima</p>
              <p className="font-medium text-black">{order.recipientName || '-'}</p>
              <p className="text-slate-600">{order.phoneNumber || '-'}</p>
            </div>
            <div>
              <p className="text-slate-500 mb-1">Alamat</p>
              <p className="text-black">{order.shippingAddress || '-'}</p>
            </div>
            {order.notes && (
              <div>
                <p className="text-slate-500 mb-1">Catatan</p>
                <p className="text-black">{order.notes}</p>
              </div>
            )}
          </div>
        </div>

        {order.paymentReceipt && (
          <div className="bg-white p-6 rounded-none border-2 border-black shadow-[4px_4px_0_0_#000]">
            <h3 className="font-bold text-black mb-4">Bukti Pembayaran</h3>
            <div className="aspect-video w-full rounded-none overflow-hidden bg-slate-100">
              <img src={order.paymentReceipt} alt="Bukti Pembayaran" className="w-full h-full object-contain" />
            </div>
          </div>
        )}
      </div>

    </div>
  );
}
