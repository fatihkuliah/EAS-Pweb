import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAppContext } from '../context.tsx';

export default function Register() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const { login } = useAppContext();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) {
      alert('Password dan Konfirmasi Password tidak cocok!');
      return;
    }
    // Simulate register & auto-login
    login(formData.email);
    navigate('/');
  };

  return (
    <div className="max-w-md mx-auto px-4 py-16">
      <div className="bg-white p-8 rounded-none border-2 border-black shadow-[4px_4px_0_0_#000]">
        <h1 className="text-3xl font-bold text-black mb-2 text-center">Buat Akun</h1>
        <p className="text-slate-500 text-center mb-8">Daftar untuk mulai memesan di MieME.</p>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Nama Lengkap</label>
            <input 
              type="text" 
              required
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
              className="w-full px-4 py-2 border-2 border-black rounded-none focus:ring-slate-900 focus:border-slate-900"
              placeholder="Budi Santoso"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Email</label>
            <input 
              type="email" 
              required
              value={formData.email}
              onChange={(e) => setFormData({...formData, email: e.target.value})}
              className="w-full px-4 py-2 border-2 border-black rounded-none focus:ring-slate-900 focus:border-slate-900"
              placeholder="email@contoh.com"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Password</label>
            <input 
              type="password" 
              required
              value={formData.password}
              onChange={(e) => setFormData({...formData, password: e.target.value})}
              className="w-full px-4 py-2 border-2 border-black rounded-none focus:ring-slate-900 focus:border-slate-900"
              placeholder="••••••••"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Konfirmasi Password</label>
            <input 
              type="password" 
              required
              value={formData.confirmPassword}
              onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
              className="w-full px-4 py-2 border-2 border-black rounded-none focus:ring-slate-900 focus:border-slate-900"
              placeholder="••••••••"
            />
          </div>

          <button 
            type="submit"
            className="w-full bg-black text-white font-bold py-3 rounded-none hover:bg-slate-800 transition-colors"
          >
            Daftar
          </button>
        </form>

        <p className="text-center text-sm text-slate-600 mt-8">
          Sudah punya akun?{' '}
          <Link to="/login" className="font-semibold text-black hover:underline">
            Masuk
          </Link>
        </p>
      </div>
    </div>
  );
}
