import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { mockMenu } from '../data.ts';
import { useAppContext } from '../context.tsx';

export default function Menu() {
  const [filter, setFilter] = useState<'all' | 'makanan' | 'minuman'>('all');
  const { addToCart } = useAppContext();

  const filteredMenu = mockMenu.filter(item => 
    filter === 'all' ? true : item.category === filter
  );

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Katalog Menu</h1>
        <p className="text-slate-600">Jelajahi berbagai pilihan menu otentik kami.</p>
      </div>

      {/* Filter Tabs */}
      <div className="flex justify-center mb-10">
        <div className="inline-flex bg-slate-100 p-1 rounded-none">
          <button 
            onClick={() => setFilter('all')}
            className={`px-6 py-2 text-sm font-medium rounded-none transition-colors ${filter === 'all' ? 'bg-white shadow-[4px_4px_0_0_#000] text-black' : 'text-slate-500 hover:text-slate-700'}`}
          >
            Semua
          </button>
          <button 
            onClick={() => setFilter('makanan')}
            className={`px-6 py-2 text-sm font-medium rounded-none transition-colors ${filter === 'makanan' ? 'bg-white shadow-[4px_4px_0_0_#000] text-black' : 'text-slate-500 hover:text-slate-700'}`}
          >
            Makanan
          </button>
          <button 
            onClick={() => setFilter('minuman')}
            className={`px-6 py-2 text-sm font-medium rounded-none transition-colors ${filter === 'minuman' ? 'bg-white shadow-[4px_4px_0_0_#000] text-black' : 'text-slate-500 hover:text-slate-700'}`}
          >
            Minuman
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {filteredMenu.map((item) => (
          <div key={item.id} className="bg-white rounded-none border-2 border-black overflow-hidden hover:shadow-[8px_8px_0_0_#000] transition-shadow group flex flex-col">
            <Link to={`/menu/${item.id}`} className="block relative aspect-[4/3] overflow-hidden bg-slate-100">
              <img 
                src={item.image} 
                alt={item.name} 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <span className="absolute bottom-2 left-2 bg-black/60 text-white text-xs px-2 py-1 rounded backdrop-blur-sm">
                ⏱ {item.estimatedTime}
              </span>
            </Link>
            <div className="p-4 flex flex-col flex-grow">
              <Link to={`/menu/${item.id}`} className="hover:underline">
                <h3 className="font-bold text-black mb-1">{item.name}</h3>
              </Link>
              <p className="text-sm text-slate-500 line-clamp-2 mb-4 flex-grow">{item.description}</p>
              
              <div className="flex items-center justify-between mt-auto">
                <span className="font-bold text-lg">Rp {item.price.toLocaleString('id-ID')}</span>
                <button 
                  onClick={() => addToCart(item, 1)}
                  className="bg-black text-white text-sm font-medium px-4 py-2 rounded-none hover:bg-slate-800 transition-colors"
                >
                  Tambah
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
