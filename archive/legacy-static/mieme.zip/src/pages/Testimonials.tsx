import React from 'react';
import { Star } from 'lucide-react';

export default function Testimonials() {
  const reviews = [
    {
      name: "Andi Wijaya",
      role: "Food Blogger",
      comment: "Mie ayam truffle-nya luar biasa! Tekstur mie pas banget, al dente. Kuahnya rich dan aroma truffle-nya dapet banget tanpa nabrak rasa ayamnya. 10/10.",
      rating: 5,
      date: "20 Okt 2023"
    },
    {
      name: "Siti Nurhaliza",
      role: "Pecinta Pedas",
      comment: "Mie Pedas Mampus benar-benar tidak mengecewakan. Pedasnya nendang tapi masih bisa dinikmati rasa gurihnya. Pangsitnya juga crispy.",
      rating: 5,
      date: "15 Sep 2023"
    },
    {
      name: "Budi Santoso",
      role: "Pelanggan Setia",
      comment: "Selalu pesan original setiap minggu, kualitas dan rasanya selalu konsisten sejak awal buka. Recommended untuk makan siang.",
      rating: 4,
      date: "5 Agu 2023"
    },
    {
      name: "Dian Sastro",
      role: "Mahasiswa",
      comment: "Porsinya mengenyangkan, harga bersahabat untuk kualitas artisan mie seperti ini. Es lecinya segar banget buat temen makan mie.",
      rating: 5,
      date: "12 Jul 2023"
    }
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 py-16">
      <div className="text-center mb-16">
        <h1 className="text-4xl font-bold mb-4 text-black">Apa Kata Mereka?</h1>
        <p className="text-slate-600 max-w-2xl mx-auto">
          Kepuasan pelanggan adalah prioritas kami. Berikut adalah pengalaman mereka menikmati hidangan MieME.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        {reviews.map((review, idx) => (
          <div key={idx} className="bg-white p-6 rounded-none border-2 border-black shadow-[4px_4px_0_0_#000] relative">
            <div className="flex text-yellow-400 mb-4">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className={`w-5 h-5 ${i < review.rating ? 'fill-current' : 'text-slate-300'}`} />
              ))}
            </div>
            <p className="text-slate-700 italic mb-6">"{review.comment}"</p>
            <div className="flex items-center justify-between border-t-2 border-black pt-4 mt-auto">
              <div>
                <p className="font-bold text-black">{review.name}</p>
                <p className="text-xs text-slate-500">{review.role}</p>
              </div>
              <p className="text-xs text-slate-400">{review.date}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
