import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

export default function FAQ() {
  const faqs = [
    {
      q: "Bagaimana cara memesan makanan di MieME?",
      a: "Anda dapat menelusuri katalog menu kami, memilih makanan/minuman yang diinginkan, tambahkan ke keranjang, dan ikuti langkah checkout hingga pembayaran selesai."
    },
    {
      q: "Metode pembayaran apa saja yang diterima?",
      a: "Kami menerima Transfer Bank (BCA, Mandiri, BNI), E-Wallet (GoPay, OVO, Dana), Virtual Account, dan QRIS."
    },
    {
      q: "Berapa lama estimasi pengiriman pesanan?",
      a: "Estimasi pembuatan makanan adalah 15-20 menit. Lama pengiriman bergantung pada jarak alamat Anda dari outlet kami, rata-rata 20-45 menit."
    },
    {
      q: "Apakah makanan di MieME halal?",
      a: "Ya, seluruh daging, kaldu, bahan baku, dan proses penyajian kami telah tersertifikasi Halal MUI."
    },
    {
      q: "Bagaimana jika pesanan saya tidak sesuai?",
      a: "Anda dapat menghubungi customer service kami melalui detail kontak di halaman bawah (footer) dan menyertakan foto pesanan dan nomor pesanan yang diterima."
    }
  ];

  const [openIdx, setOpenIdx] = useState<number | null>(0);

  return (
    <div className="max-w-3xl mx-auto px-4 py-16">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4 text-black">FAQ</h1>
        <p className="text-slate-600">Pertanyaan yang sering diajukan seputar layanan kami.</p>
      </div>

      <div className="space-y-4">
        {faqs.map((faq, idx) => (
          <div key={idx} className="bg-white border-2 text-left border-black rounded-none overflow-hidden">
            <button 
              className="w-full px-6 py-4 text-left flex justify-between items-center bg-white hover:bg-slate-200 transition-colors"
              onClick={() => setOpenIdx(openIdx === idx ? null : idx)}
            >
              <span className="font-bold text-black">{faq.q}</span>
              {openIdx === idx ? <ChevronUp className="w-5 h-5 text-slate-500" /> : <ChevronDown className="w-5 h-5 text-slate-500" />}
            </button>
            {openIdx === idx && (
              <div className="px-6 py-4 bg-slate-200 border-t-2 border-black text-slate-600 leading-relaxed">
                {faq.a}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
